import Visual.loging;
public class Main {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new loging().setVisible(true);
        });
    }
}
