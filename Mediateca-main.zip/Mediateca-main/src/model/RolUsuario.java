package model;

public enum RolUsuario {
    ADMIN,
    PROFESOR,
    ALUMNO
}
